from pathlib import Path
exec(compile(Path('workspace/agent3_run_all_checks.py').read_text(),'workspace/agent3_run_all_checks.py','exec'),{'__name__':'__main__'})
exec(compile(Path('workspace/agent1_exact_finite_minima.py').read_text(),'workspace/agent1_exact_finite_minima.py','exec'),{'__name__':'__main__'})
print('ALL CHECKS PASSED')
