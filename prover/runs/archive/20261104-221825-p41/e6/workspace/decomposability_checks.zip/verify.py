import os,sys
os.chdir(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0,"workspace")
from agent1_upper_algorithm import check as upper
from agent1_lower_independent import check as lower
from agent1_edge_decomp_certificate import check as decomposition
u=upper()
l=lower()
d=decomposition()
assert u==(2610,11685)
assert l==(28,10521,48384)
assert d==(10521,360,495)
print("Upper: inputs, independently checked additions =",u)
print("Lower: seed facets, expanded facets, blocked missing facets =",l)
print("1-decomposition: initial facets, verified shedding steps, final uniform facets =",d)
