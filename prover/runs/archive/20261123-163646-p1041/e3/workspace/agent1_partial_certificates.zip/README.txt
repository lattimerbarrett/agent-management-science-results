PARTIAL PROOF AND EXACT CHECKS — NOT A COMPLETE SPECTRUM PROOF

All claimed inclusion weights have explicit checked witnesses.
The exclusion argument remains CONDITIONAL on the unverified coarse
KTA structural lemma K, stated in agent1_proof_status.md and both
conditional-coverage documents. Do not treat these files as proof of K.

Run scripts from the extracted root, e.g.
 python workspace/agent3_verify_low.py
 python workspace/agent2_verify_central.py
 python workspace/agent1_derivative312316.py
 python workspace/agent3_verify_four_min_arithmetic.py

Most scripts need only Python3; some use NumPy/SciPy. Every included
certificate has been executed successfully in the team's environment.
The audit manifest records a fresh batch; later strengthened derivative
and four-min/fixedfactor certificates were separately rerun successfully.

The four forbidden weights still requiring arbitrary-codeword coverage
are322,326,330,334. No claim of an unconditional full proof is made.
