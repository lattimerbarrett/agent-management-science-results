# Reed–Muller spectrum proof status (agent 1 audit)

The displayed 33-interval candidate is NOT yet proved by this team's work.

## Unconditional parts
* All 21 positive exceptional low weights have explicit RM(7,14) witnesses,
  checked at all 16384 points and by full ANF transform.
* All even weights [336,16384-336] have explicit constructions from64
  checked witnesses plus disjoint7-flat toggles and complementation.
* The embeddings and Plotkin disjoint-sum induction prove all claimed
  inclusions for every m>=14.
* Classical KT/KTA numerical low-weight results exclude all missing weights
  below320. The four outstanding exclusions are322,326,330,334.
* The group-algebra quadratic refinement reduces these exclusions to m14
  and the constant-Q m15 case.
* All relative odd-gap, periodic-slice, derivative-footprint and canonical
  three-flat geometry lemmas in the listed scripts have been proved and
  independently checked. See agent1_audit_manifest.json for fresh execution.

## Single unresolved structural input
K(r,n): Every RM(r,n) word of weight<5*2^(n-r-1) is either XOR of at most
three minimum words, or its affine support span has dimension<=n-r+4.

This assertion has NOT been established or verified from a source.
It must not be silently attributed to the KTA weight-enumerator theorem.
Only K(6,13), K(5,12) and K(8,14) are required by the current proof.

Conditional on K, the complete m14 exclusion proof is
agent3_m14_conditional_coverage.txt, and the m15 constant-Q exclusion proof
is agent2_constantQ15_conditional_proof.txt. There are no other identified
gaps in those conditional arguments after agent1's audit.

## Core executable audit
agent1_audit_manifest.json records13 scripts freshly executed successfully.
This audit verifies only the assertions in the scripts, NOT K, and hence
is not an unconditional certificate of the four missing-weight exclusions.
