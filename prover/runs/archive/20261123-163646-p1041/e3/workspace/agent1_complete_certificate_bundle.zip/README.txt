COMPLETE PROOF AND EXECUTABLE CERTIFICATES

Start with agent3_final_global_proof.txt. Full exclusions are in agent4_m14_unconditional_proof.txt and agent2_constantQ15_unconditional_proof.txt. All formerly unproved coarse structural K inputs have been REMOVED. Classical strict Kasami--Tokura and Kasami--Tokura--Azumi NUMERICAL theorems remain explicit established external inputs.

Run python agent1_final_certificate.py for the self-contained standard-library checks (85 full seed truth tables and ANF transforms, empty-block middle constructions, bootstrap/Pluecker/fiber/intersection arithmetic, small exhaustive group algebra identities). Run python agent4_verify_m14_unconditional.py for the consolidated supplemental m14 checks. The scripts do not pretend to brute-force the enormous RM code: the included mathematical proofs establish universal coverage.

All core checks were independently executed by multiple agents and passed. The JSON manifests record exact hashes, stdout, and timings. Old conditional files and partial bundles are historical and are intentionally NOT included.
